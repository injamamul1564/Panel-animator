This folder is optional.

The app can open .cbz and .pdf files without anything here, AS LONG AS the
phone has internet the first time it needs pdf.js / JSZip — it quietly
downloads them from a CDN in that case.

To make opening .cbz/.pdf work with ZERO internet connection ever, download
these 3 files yourself and place them directly in this folder (same names,
no subfolders) before building the app:

  pdf.min.js         https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js
  pdf.worker.min.js  https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js
  jszip.min.js       https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js

Everything else in the app (animation, coloring, strip view, video export)
needs no internet and no files here at all.
