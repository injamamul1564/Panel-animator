package com.panelanimator.app

import android.app.Activity
import android.content.ContentValues
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        webView = WebView(this)
        setContentView(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.mediaPlaybackRequiresUserGesture = false
        // The page is loaded from a local asset but still calls out to CDN
        // libraries over https (see MainActivity's note in the app README
        // about the offline lib/ folder) — explicitly allow that mix rather
        // than relying on the platform default.
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidDownloader(this), "AndroidDownloader")

        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if(webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    /**
     * Bridge the page's triggerDownload() calls to the device's real
     * Downloads folder. A plain WebView can't act on a blob: URL the way a
     * full browser tab can, so index.html base64-encodes the file and hands
     * it to this instead whenever it detects it's running inside this app.
     */
    private class AndroidDownloader(private val activity: Activity) {
        @JavascriptInterface
        fun saveBase64(base64: String, filename: String, mime: String) {
            try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val resolver = activity.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, filename)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri == null) {
                    postToast("Couldn't save $filename")
                    return
                }
                resolver.openOutputStream(uri)?.use { it.write(bytes) }
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                postToast("Saved $filename to Downloads")
            } catch (e: Exception) {
                Log.e("AndroidDownloader", "Failed to save $filename", e)
                postToast("Download failed: ${e.message}")
            }
        }

        private fun postToast(msg: String) {
            activity.runOnUiThread {
                Toast.makeText(activity, msg, Toast.LENGTH_LONG).show()
            }
        }
    }
}
