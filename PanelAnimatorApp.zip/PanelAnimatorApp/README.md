# Panel Animator — Android project

This is a real Android Studio project. It wraps the manga animator as a
native app: the HTML/CSS/JS lives inside the app itself (`app/src/main/assets/index.html`),
not on a website — there's nothing to host.

## What you need

- **Android Studio** (free): https://developer.android.com/studio
- That's it. Android Studio includes everything else (JDK, Android SDK,
  Gradle) and will offer to install/configure them on first launch if
  they're missing.

## How to build it

1. Open Android Studio → "Open" → select this `PanelAnimatorApp` folder.
2. Let it sync (first sync can take a few minutes — it's downloading Gradle
   and the Android SDK pieces it needs). If it prompts you to upgrade the
   Android Gradle Plugin or Gradle version, accept it — that's normal and
   expected on a fresh project.
3. Plug in an Android phone (with USB debugging on) **or** use Android
   Studio's built-in emulator.
4. Click the green ▶ Run button. The app installs and launches.

### To get an installable `.apk` file (not just run from the IDE)

Build menu → **Build Bundle(s) / APK(s) → Build APK(s)**. When it finishes,
click the "locate" link in the notification — you'll find
`app-debug.apk` there. Copy that file to any Android phone and open it to
install (you'll need to allow "install unknown apps" for whatever app you
used to open it, since it isn't from the Play Store).

## Notes

- **Downloads** (the Pages .zip / PDF / video export buttons) are wired up
  to save straight into the phone's real Downloads folder via a small
  native bridge — see `MainActivity.kt` — since a plain WebView can't
  handle a browser-style blob download on its own.
- **Opening .cbz/.pdf files** needs two small libraries (pdf.js, JSZip).
  See `app/src/main/assets/lib/README.txt` for how to bundle them for
  fully offline use, or just leave it as-is and the app will fetch them
  from a CDN the first time it needs them (only if the phone has internet
  at that moment).
- The app icon is the simple stacked-panels mark already generated for you
  — swap the files under `app/src/main/res/mipmap-*/` if you want your own.
- This targets Android 10 and newer (minSdk 29), which keeps the download
  code simple (no storage permission prompts needed). If you need to
  support older phones, say so and that can be added back in.
